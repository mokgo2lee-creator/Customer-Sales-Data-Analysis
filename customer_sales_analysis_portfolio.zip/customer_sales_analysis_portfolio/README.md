# Customer Sales Data Analysis

**Beginner Data Analyst Portfolio Project**

## Project overview
This project analyses a sample retail sales dataset to explore sales performance, customer activity, regional results, product categories and payment methods.

### Business questions
- How much revenue and estimated profit did the business generate?
- How did sales change month by month?
- Which regions and product categories performed best?
- Which payment methods were most commonly used?
- What actions could management consider based on the findings?

## Tools
- Python
- pandas
- matplotlib
- Jupyter Notebook / Google Colab

## Dataset
The file `data/sales_data.csv` contains 600 synthetic order records covering 2025. It includes order dates, customer IDs, regions, product categories, units, prices, discounts, sales, costs and payment methods.

**Important:** The dataset is computer-generated for educational and portfolio use. It is not real company or customer data. Financial amounts are in South African rand (ZAR).

## How to run the project
### Option 1: Google Colab
1. Download this repository to your computer and unzip it.
2. Open [Google Colab](https://colab.research.google.com/).
3. Upload `notebooks/customer_sales_analysis.ipynb`.
4. Upload `data/sales_data.csv` to the Colab session.
5. In the notebook, use the Colab upload option shown in the commented code in Section 2, or update the CSV path to `/content/sales_data.csv`.
6. Run the notebook from top to bottom.

### Option 2: Run locally
1. Install Python.
2. Install dependencies: `pip install pandas matplotlib jupyter`
3. Open the notebook in Jupyter.
4. Run all cells.

## Project structure
```text
customer_sales_analysis_portfolio/
├── data/
│   └── sales_data.csv
├── notebooks/
│   └── customer_sales_analysis.ipynb
├── images/
├── README.md
└── requirements.txt
```

## Analysis included
- Data inspection and quality checks
- Duplicate and missing-value checks
- Feature creation (month, profit and profit margin)
- Key performance indicators
- Monthly sales trend
- Sales by region
- Sales and profit by category
- Payment method analysis
- Findings and business recommendations

## Next improvements
- Build an interactive Power BI dashboard.
- Add SQL queries for the same business questions.
- Test findings on a real, appropriately licensed dataset.
- Add exported charts and a short executive summary.

## Author
**Your name:** Add your name here  
**LinkedIn:** Add your LinkedIn profile URL here

---
This project was created for learning and skills demonstration.
